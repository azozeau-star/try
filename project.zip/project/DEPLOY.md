# Publish Sami Says

The static website is in `docs/`. It is plain HTML and can be published with GitHub Pages; Jekyll is not required. The Node.js service must also stay deployed to provide real AI responses, sign-in, and saved chats.

## 1. Upload the project to GitHub

Create a GitHub repository and upload the project files, including `docs/` and `assets/`. Do not upload `.env`, `.data/`, or `node_modules/`. The existing `.gitignore` excludes them.

## 2. Deploy the Node.js service on Render

Create a Render Web Service connected to the repository:

- Build command: `npm install`
- Start command: `npm start`

Add these environment variables in Render:

- `GROQ_API_KEY`: your Groq API key
- `ADMIN_PASSWORD`: a long, unique password for the developer dashboard
- `STATIC_SITE_ORIGIN`: the GitHub Pages origin, for example `https://your-name.github.io` (do not include the repository path)

Keep the API key and admin password in Render's environment settings only. Never put them in `docs/config.js` or commit them.

## 3. Point the static site at the backend

Edit `docs/config.js` and replace `https://YOUR-SERVICE-NAME.onrender.com` with the Render service URL.

## 4. Enable GitHub Pages

In the GitHub repository, open **Settings → Pages**. Select **Deploy from a branch**, choose the `main` branch and the `/docs` folder, then save. GitHub will show the public site URL after deployment.

If the GitHub Pages origin changes, update both `docs/config.js` and Render's `STATIC_SITE_ORIGIN`, then redeploy.

## Demo limitations

The current backend stores accounts and chats in a local JSON file. On a free Render service that file is not durable and may be lost after a restart or redeploy. The free service may also sleep when idle. Move the data to a managed database before relying on it for real users.

The static site and Render API use different domains. The backend sets cross-site cookies for this setup, but browsers that block third-party cookies may prevent sign-in. A custom domain with the API on a matching subdomain or an auth provider is needed to avoid that browser limitation reliably.
