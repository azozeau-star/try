window.SAMI_BACKEND_URL = 'https://YOUR-SERVICE-NAME.onrender.com';
