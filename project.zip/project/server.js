const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const OpenAI = require('openai');
const fs = require('fs');
const path = require('path');
const { createHash, randomBytes, scrypt, timingSafeEqual } = require('crypto');
const { promisify } = require('util');
require('dotenv').config();

// --- CONFIGURATION ---
const GROQ_API_KEY = process.env.GROQ_API_KEY;
const PORT = Number(process.env.PORT) || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const STATIC_SITE_ORIGIN = process.env.STATIC_SITE_ORIGIN;
const groq = GROQ_API_KEY
    ? new OpenAI({ apiKey: GROQ_API_KEY, baseURL: 'https://api.groq.com/openai/v1' })
    : null;
const scryptAsync = promisify(scrypt);
// ---------------------

const app = express();
app.use((req, res, next) => {
    const origin = req.get('Origin');
    if (origin && STATIC_SITE_ORIGIN && origin !== STATIC_SITE_ORIGIN) {
        return res.status(403).json({ error: 'هذا الموقع غير مسموح له بالاتصال بالخادم.' });
    }
    if (origin && origin === STATIC_SITE_ORIGIN) {
        res.setHeader('Access-Control-Allow-Origin', origin);
        res.setHeader('Access-Control-Allow-Credentials', 'true');
        res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
        res.setHeader('Vary', 'Origin');
        if (req.method === 'OPTIONS') return res.sendStatus(204);
    }
    return next();
});
const server = http.createServer(app);
const io = new Server(server, {
    cors: STATIC_SITE_ORIGIN ? { origin: STATIC_SITE_ORIGIN, credentials: true } : undefined
});

const DATA_DIRECTORY = path.join(__dirname, '.data');
const DATA_FILE = path.join(DATA_DIRECTORY, 'accounts.json');
fs.mkdirSync(DATA_DIRECTORY, { recursive: true });
let database = { users: [], chats: {}, sessions: [] };
if (fs.existsSync(DATA_FILE)) {
    database = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    if (!Array.isArray(database.users) || !database.chats || typeof database.chats !== 'object') {
        throw new Error('The account database has an invalid format.');
    }
    if (!Array.isArray(database.sessions)) database.sessions = [];
}

function persistDatabase() {
    const tempFile = `${DATA_FILE}.${process.pid}.tmp`;
    fs.writeFileSync(tempFile, JSON.stringify(database), { mode: 0o600 });
    fs.renameSync(tempFile, DATA_FILE);
}

const activeChats = {};
const sessionFromCookie = (cookieHeader = '') => {
    const cookie = cookieHeader.split(';').map((item) => item.trim()).find((item) => item.startsWith('sami_session='));
    if (!cookie) return null;
    const token = cookie.slice('sami_session='.length);
    const tokenHash = createHash('sha256').update(token).digest('hex');
    const index = database.sessions.findIndex((session) => session.tokenHash === tokenHash);
    if (index < 0) return null;
    if (database.sessions[index].expiresAt <= Date.now()) {
        database.sessions.splice(index, 1);
        persistDatabase();
        return null;
    }
    return { ...database.sessions[index], tokenHash };
};

function setSessionCookie(res, token) {
    const crossSite = Boolean(STATIC_SITE_ORIGIN);
    const secure = res.req.secure || crossSite ? ' Secure;' : '';
    const sameSite = crossSite ? 'None' : 'Lax';
    res.setHeader('Set-Cookie', `sami_session=${token}; HttpOnly;${secure} SameSite=${sameSite}; Path=/; Max-Age=604800`);
}

function createSession(res, session) {
    const token = randomBytes(32).toString('hex');
    const tokenHash = createHash('sha256').update(token).digest('hex');
    database.sessions = database.sessions.filter((entry) => entry.expiresAt > Date.now());
    database.sessions.push({ ...session, tokenHash, expiresAt: Date.now() + 7 * 24 * 60 * 60 * 1000 });
    persistDatabase();
    setSessionCookie(res, token);
}

function publicUser(user) {
    return { id: user.id, name: user.name, email: user.email };
}

async function hashPassword(password, salt = randomBytes(16).toString('hex')) {
    const derivedKey = await scryptAsync(password, salt, 64);
    return { salt, hash: derivedKey.toString('hex') };
}

async function verifyPassword(password, user) {
    const { hash } = await hashPassword(password, user.salt);
    const expected = Buffer.from(user.passwordHash, 'hex');
    const actual = Buffer.from(hash, 'hex');
    return expected.length === actual.length && timingSafeEqual(actual, expected);
}

const failedLoginAttempts = new Map();
function loginIsRateLimited(key) {
    const now = Date.now();
    for (const [attemptKey, attempt] of failedLoginAttempts) {
        if (attempt.startedAt <= now - 15 * 60 * 1000) failedLoginAttempts.delete(attemptKey);
    }
    const attempt = failedLoginAttempts.get(key);
    return Boolean(attempt && attempt.count >= 5);
}

function recordFailedLogin(key) {
    const now = Date.now();
    const attempt = failedLoginAttempts.get(key);
    if (!attempt || attempt.startedAt <= now - 15 * 60 * 1000) {
        failedLoginAttempts.set(key, { count: 1, startedAt: now });
    } else {
        attempt.count += 1;
    }
}

app.use(express.json({ limit: '16kb' }));

app.get('/api/me', (req, res) => {
    const session = sessionFromCookie(req.headers.cookie);
    if (!session) return res.json({ authenticated: false });
    if (session.role === 'admin') return res.json({ authenticated: true, role: 'admin' });
    const user = database.users.find((entry) => entry.id === session.userId);
    if (!user) return res.json({ authenticated: false });
    return res.json({ authenticated: true, role: 'user', user: publicUser(user) });
});

app.post('/api/signup', async (req, res, next) => {
    try {
        const body = req.body && typeof req.body === 'object' ? req.body : {};
        const name = typeof body.name === 'string' ? body.name.trim().replace(/\s+/g, ' ').slice(0, 50) : '';
        const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
        const password = typeof body.password === 'string' ? body.password : '';
        if (!name || email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 8 || password.length > 128) {
            return res.status(400).json({ error: 'أدخل اسماً وبريداً إلكترونياً صحيحاً وكلمة مرور من 8 أحرف على الأقل.' });
        }
        if (database.users.some((user) => user.email === email)) {
            return res.status(409).json({ error: 'يوجد حساب بهذا البريد الإلكتروني. سجّل الدخول بدلاً من ذلك.' });
        }

        const { salt, hash } = await hashPassword(password);
        if (database.users.some((user) => user.email === email)) {
            return res.status(409).json({ error: 'يوجد حساب بهذا البريد الإلكتروني. سجّل الدخول بدلاً من ذلك.' });
        }
        const user = { id: randomBytes(16).toString('hex'), name, email, salt, passwordHash: hash };
        database.users.push(user);
        database.chats[user.id] = { displayName: name, messages: [] };
        persistDatabase();
        createSession(res, { role: 'user', userId: user.id });
        return res.status(201).json({ authenticated: true, role: 'user', user: publicUser(user) });
    } catch (error) {
        return next(error);
    }
});

app.post('/api/login', async (req, res, next) => {
    try {
        const attemptKey = `user:${req.ip}`;
        if (loginIsRateLimited(attemptKey)) return res.status(429).json({ error: 'محاولات كثيرة. حاول مرة أخرى بعد 15 دقيقة.' });
        const body = req.body && typeof req.body === 'object' ? req.body : {};
        const email = typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
        const password = typeof body.password === 'string' ? body.password : '';
        const user = database.users.find((entry) => entry.email === email);
        if (!user || password.length > 128 || !await verifyPassword(password, user)) {
            recordFailedLogin(attemptKey);
            return res.status(401).json({ error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' });
        }
        failedLoginAttempts.delete(attemptKey);
        createSession(res, { role: 'user', userId: user.id });
        return res.json({ authenticated: true, role: 'user', user: publicUser(user) });
    } catch (error) {
        return next(error);
    }
});

app.post('/api/admin/login', (req, res) => {
    if (!ADMIN_PASSWORD) {
        return res.status(503).json({ error: 'لم يتم إعداد كلمة مرور لوحة المطور. أضف ADMIN_PASSWORD إلى ملف .env.' });
    }
    const attemptKey = `admin:${req.ip}`;
    if (loginIsRateLimited(attemptKey)) return res.status(429).json({ error: 'محاولات كثيرة. حاول مرة أخرى بعد 15 دقيقة.' });
    const body = req.body && typeof req.body === 'object' ? req.body : {};
    const password = typeof body.password === 'string' ? Buffer.from(body.password) : Buffer.alloc(0);
    const expected = Buffer.from(ADMIN_PASSWORD);
    if (password.length !== expected.length || !timingSafeEqual(password, expected)) {
        recordFailedLogin(attemptKey);
        return res.status(401).json({ error: 'كلمة مرور لوحة المطور غير صحيحة.' });
    }
    failedLoginAttempts.delete(attemptKey);
    createSession(res, { role: 'admin' });
    return res.json({ authenticated: true, role: 'admin' });
});

app.post('/api/logout', (req, res) => {
    const cookie = (req.headers.cookie || '').split(';').map((item) => item.trim()).find((item) => item.startsWith('sami_session='));
    if (cookie) {
        const token = cookie.slice('sami_session='.length);
        const tokenHash = createHash('sha256').update(token).digest('hex');
        const index = database.sessions.findIndex((entry) => entry.tokenHash === tokenHash);
        const session = index >= 0 ? database.sessions[index] : null;
        if (index >= 0) database.sessions.splice(index, 1);
        persistDatabase();
        if (session) {
            for (const connectedSocket of io.sockets.sockets.values()) {
                if (connectedSocket.sessionTokenHash === tokenHash) connectedSocket.disconnect(true);
            }
        }
    }
    const crossSite = Boolean(STATIC_SITE_ORIGIN);
    const secure = res.req.secure || crossSite ? ' Secure;' : '';
    const sameSite = crossSite ? 'None' : 'Lax';
    res.setHeader('Set-Cookie', `sami_session=; HttpOnly;${secure} SameSite=${sameSite}; Path=/; Max-Age=0`);
    return res.json({ success: true });
});

io.use((socket, next) => {
    const session = sessionFromCookie(socket.handshake.headers.cookie);
    if (!session) return next(new Error('Authentication required'));
    socket.sessionTokenHash = session.tokenHash;
    if (session.role === 'admin') {
        socket.role = 'admin';
        return next();
    }
    const user = database.users.find((entry) => entry.id === session.userId);
    if (!user) return next(new Error('Authentication required'));
    socket.role = 'user';
    socket.accountId = user.id;
    socket.accountName = user.name;
    return next();
});

async function getMedicalAIResponse(userMessage) {
    if (!groq) {
        return "المساعد الطبي غير متصل حالياً. أضف مفتاح Groq إلى ملف .env ثم أعد تشغيل الخادم.";
    }

    try {
        const completion = await groq.chat.completions.create({
            model: "allam-2-7b",
            messages: [
                {
                    role: "system",
                    content: "You are a strict medical AI assistant speaking in Arabic. You must ONLY answer questions related to medicine, health, anatomy, and biology. If the user asks about anything else, reply EXACTLY with: \"عذراً، أنا مساعد طبي ويمكنني فقط الإجابة على الأسئلة المتعلقة بالصحة والطب.\""
                },
                {
                    role: "user",
                    content: userMessage
                }
            ],
            temperature: 0.2,
            max_tokens: 300
        });

        return completion.choices[0]?.message?.content?.trim() || "المساعد الطبي غير متصل حالياً. سيقوم أحد المطورين بالرد عليك قريباً.";
    } catch (error) {
        console.error("AI Error:", error);
        return "المساعد الطبي غير متصل حالياً. سيقوم أحد المطورين بالرد عليك قريباً.";
    }
}

io.on('connection', (socket) => {
    if (socket.role === 'admin') {
        socket.join('admins');
        socket.emit('active_users', Object.entries(activeChats).map(([userId, chat]) => ({
            userId,
            displayName: chat.displayName
        })));

        socket.on('load_admin_chat', (userId) => {
            const chat = activeChats[userId];
            if (chat) {
                socket.emit('admin_chat_history', { userId, displayName: chat.displayName, messages: chat.messages });
                socket.emit('admin_takeover_state', { userId, humanTakeover: chat.humanTakeover });
            }
        });

        socket.on('admin_set_takeover', (data) => {
            if (!data || typeof data.userId !== 'string' || typeof data.enabled !== 'boolean') return;
            const chat = activeChats[data.userId];
            if (!chat) return;
            chat.humanTakeover = data.enabled;
            io.to('admins').emit('admin_takeover_state', {
                userId: data.userId,
                humanTakeover: chat.humanTakeover
            });
        });

        socket.on('admin_message', (data) => {
            if (!data || typeof data.userId !== 'string' || typeof data.text !== 'string') return;
            const chat = activeChats[data.userId];
            if (!chat || !data.text.trim()) return;
            const message = { sender: 'Developer', text: data.text.trim().slice(0, 4000) };
            chat.messages.push(message);
            persistDatabase();
            io.to(data.userId).emit('receive_message', message);
            io.to('admins').emit('update_admin_chat', {
                userId: data.userId,
                displayName: chat.displayName,
                messages: chat.messages
            });
        });
        return;
    }

    const savedChat = database.chats[socket.accountId] || { displayName: socket.accountName, messages: [] };
    savedChat.displayName = socket.accountName;
    database.chats[socket.accountId] = savedChat;
    activeChats[socket.id] = {
        accountId: socket.accountId,
        displayName: socket.accountName,
        messages: savedChat.messages,
        humanTakeover: false
    };
    persistDatabase();
    socket.emit('chat_history', savedChat.messages);
    socket.emit('takeover_state', activeChats[socket.id].humanTakeover);
    io.to('admins').emit('new_user', { userId: socket.id, displayName: socket.accountName });

    socket.on('user_message', async (text) => {
        const userId = socket.id;
        const chat = activeChats[userId];
        if (!chat || typeof text !== 'string' || !text.trim()) return;

        const message = { sender: 'user', text: text.trim().slice(0, 4000) };
        chat.messages.push(message);
        persistDatabase();
        io.to('admins').emit('update_admin_chat', { userId, displayName: chat.displayName, messages: chat.messages });

        if (!chat.humanTakeover) {
            const aiReply = await getMedicalAIResponse(message.text);
            const reply = { sender: 'AI', text: aiReply };
            chat.messages.push(reply);
            persistDatabase();

            socket.emit('receive_message', reply);
            io.to('admins').emit('update_admin_chat', { userId, displayName: chat.displayName, messages: chat.messages });
        }
    });

    socket.on('disconnect', () => {
        if (activeChats[socket.id]) {
            io.to('admins').emit('user_disconnected', socket.id);
            delete activeChats[socket.id];
        }
    });
});

app.use(express.static(path.join(__dirname, 'docs')));

// --- FRONTEND: DEVELOPER DASHBOARD (Dark mode to match) ---
app.get('/developer', (req, res) => {
    res.send(`
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
        <meta charset="UTF-8">
        <title>لوحة تحكم المطور</title>
        <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
        <style>
            body { font-family: 'Tajawal', sans-serif; display: flex; height: 100vh; margin: 0; background-color: #0a0f16; color: white; }
            #sidebar { width: 300px; background: #111826; padding: 20px; border-left: 1px solid #1f2937; overflow-y: auto; }
            .user-btn { display: block; width: 100%; padding: 15px; margin-bottom: 8px; cursor: pointer; background: #1f2937; color: white; border: none; text-align: right; border-radius: 8px; font-family: 'Tajawal', sans-serif;}
            .user-btn:hover { background: #374151; }
            #chat-area { flex-grow: 1; padding: 20px; display: flex; flex-direction: column; }
            #chat { flex-grow: 1; background: #111826; border-radius: 12px; padding: 20px; overflow-y: auto; margin-bottom: 15px; }
            .msg { margin: 10px 0; padding: 12px; background: #1f2937; border-radius: 8px; white-space: pre-wrap; }
            .controls { display: flex; gap: 10px; }
            input[type="text"] { flex-grow: 1; padding: 12px; border-radius: 8px; border: none; background: #1f2937; color: white; font-family: 'Tajawal', sans-serif; outline: none; }
            button.send-btn { padding: 12px 25px; background: #007bff; color: white; border: none; border-radius: 8px; cursor: pointer; font-family: 'Tajawal', sans-serif; }
            #takeover { padding: 10px; background: #d97706; color: white; border: none; border-radius: 8px; cursor: pointer; margin-bottom: 15px; font-family: 'Tajawal', sans-serif;}
            #admin-login { width: min(420px, calc(100% - 32px)); margin: auto; padding: 26px; border: 1px solid #1f2937; border-radius: 16px; background: #111826; }
            #admin-login label { display: grid; gap: 8px; }
            #admin-error { min-height: 24px; margin-top: 10px; color: #ff9a9a; }
            [hidden] { display: none !important; }
        </style>
    </head>
    <body>
        <form id="admin-login" hidden>
            <h2>تسجيل دخول المطور</h2>
            <label>كلمة مرور لوحة المطور
                <input id="admin-password" type="password" autocomplete="current-password" required>
            </label>
            <button class="send-btn" type="submit">تسجيل الدخول</button>
            <div id="admin-error" role="alert" aria-live="polite"></div>
        </form>
        <div id="admin-interface" hidden style="display:flex; flex:1;">
            <div id="sidebar">
                <h3>المستخدمين النشطين</h3>
                <div id="user-list"></div>
            </div>
            <div id="chat-area">
                <div style="display:flex;align-items:center;justify-content:space-between;gap:12px">
                    <h2 id="title">اختر مستخدم للبدء</h2>
                    <button class="send-btn" id="admin-logout" type="button">تسجيل الخروج</button>
                </div>
                <button id="takeover" style="display:none;">إيقاف الذكاء الاصطناعي (التحدث مباشرة)</button>
                <div id="chat"></div>
                <div class="controls">
                    <input type="text" id="input" placeholder="اكتب ردك هنا..." disabled onkeypress="handleKeyPress(event)">
                    <button class="send-btn" onclick="send()">إرسال</button>
                </div>
            </div>
        </div>
        <script src="/socket.io/socket.io.js"></script>
        <script>
            const socket = io({ autoConnect: false });
            let activeUser = null;
            let activeUserName = '';
            let activeHumanTakeover = false;
            socket.on('connect_error', () => {
                document.getElementById('admin-error').textContent = 'تعذّر التحقق من جلسة المطور. سجّل الدخول مجدداً.';
                socket.disconnect();
                document.getElementById('admin-interface').hidden = true;
                document.getElementById('admin-login').hidden = false;
            });

            function showAdminInterface() {
                document.getElementById('admin-login').hidden = true;
                document.getElementById('admin-interface').hidden = false;
                socket.connect();
            }

            document.getElementById('admin-logout').addEventListener('click', async () => {
                socket.disconnect();
                try {
                    const response = await fetch('/api/logout', { method: 'POST', credentials: 'same-origin' });
                    if (!response.ok) throw new Error('تعذّر تسجيل الخروج.');
                    location.reload();
                } catch (error) {
                    document.getElementById('admin-error').textContent = error.message;
                    socket.connect();
                }
            });

            document.getElementById('admin-login').addEventListener('submit', async (event) => {
                event.preventDefault();
                const error = document.getElementById('admin-error');
                error.textContent = '';
                try {
                    const response = await fetch('/api/admin/login', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ password: document.getElementById('admin-password').value })
                    });
                    const result = await response.json();
                    if (!response.ok) throw new Error(result.error || 'تعذّر تسجيل الدخول.');
                    showAdminInterface();
                } catch (loginError) {
                    error.textContent = loginError.message;
                }
            });

            fetch('/api/me')
                .then((response) => response.json())
                .then((result) => {
                    if (result.authenticated && result.role === 'admin') showAdminInterface();
                    else {
                        document.getElementById('admin-login').hidden = false;
                        if (result.authenticated) document.getElementById('admin-error').textContent = 'هذا الحساب غير مخوّل لدخول لوحة المطور.';
                    }
                })
                .catch(() => {
                    document.getElementById('admin-login').hidden = false;
                    document.getElementById('admin-error').textContent = 'تعذّر الاتصال بالخادم.';
                });

            function addUser(user) {
                const { userId, displayName } = user;
                let button = document.getElementById('btn-' + userId);
                if (!button) {
                    button = document.createElement('button');
                    button.className = 'user-btn';
                    button.id = 'btn-' + userId;
                    button.addEventListener('click', () => loadChat(userId));
                    document.getElementById('user-list').appendChild(button);
                }
                button.textContent = (displayName || 'مستخدم') + ' · ' + userId.substring(0, 6);
                button.dataset.displayName = displayName || 'مستخدم';
                if (activeUser === userId) {
                    activeUserName = button.dataset.displayName;
                    document.getElementById('title').innerText = 'محادثة مع: ' + activeUserName;
                }
            }

            function renderMessages(messages) {
                const chat = document.getElementById('chat');
                chat.replaceChildren();
                messages.forEach((message) => {
                    const row = document.createElement('div');
                    row.className = 'msg';
                    const sender = document.createElement('strong');
                    const senderName = message.sender === 'user'
                        ? activeUserName
                        : message.sender === 'AI'
                            ? 'الذكاء الاصطناعي'
                            : message.sender === 'Developer'
                                ? 'د.سامي'
                                : message.sender;
                    sender.textContent = senderName + ':';
                    row.append(sender, document.createTextNode(' ' + message.text));
                    chat.appendChild(row);
                });
                chat.scrollTop = chat.scrollHeight;
            }

            socket.on('active_users', (users) => users.forEach(addUser));
            socket.on('new_user', addUser);

            socket.on('update_admin_chat', (data) => {
                addUser({ userId: data.userId, displayName: data.displayName });
                if(activeUser === data.userId) {
                    renderMessages(data.messages);
                }
            });

            socket.on('admin_chat_history', (data) => {
                if(activeUser === data.userId) {
                    activeUserName = data.displayName || activeUserName;
                    document.getElementById('title').innerText = 'محادثة مع: ' + activeUserName;
                    renderMessages(data.messages);
                }
            });

            socket.on('admin_takeover_state', (data) => {
                if (activeUser === data.userId) setTakeoverButton(data.humanTakeover);
            });

            socket.on('user_disconnected', (id) => {
                const btn = document.getElementById('btn-'+id);
                if(btn) btn.remove();
                if (activeUser === id) {
                    activeUser = null;
                    activeUserName = '';
                    activeHumanTakeover = false;
                    document.getElementById('title').innerText = 'اختر مستخدم للبدء';
                    document.getElementById('chat').replaceChildren();
                    document.getElementById('input').disabled = true;
                    document.getElementById('takeover').style.display = 'none';
                }
            });

            function setTakeoverButton(humanTakeover) {
                activeHumanTakeover = humanTakeover;
                const takeover = document.getElementById('takeover');
                takeover.textContent = humanTakeover
                    ? 'استئناف رد الذكاء الاصطناعي'
                    : 'إيقاف الذكاء الاصطناعي (التحدث مباشرة)';
                takeover.style.background = humanTakeover ? '#047857' : '#d97706';
                takeover.setAttribute('aria-pressed', String(humanTakeover));
            }

            function loadChat(id) {
                activeUser = id;
                activeHumanTakeover = false;
                const button = document.getElementById('btn-' + id);
                activeUserName = button ? button.dataset.displayName : 'مستخدم';
                document.getElementById('title').innerText = 'محادثة مع: ' + activeUserName;
                document.getElementById('input').disabled = false;
                document.getElementById('chat').replaceChildren();
                socket.emit('load_admin_chat', id);
                const takeover = document.getElementById('takeover');
                takeover.style.display = 'inline-block';
                setTakeoverButton(activeHumanTakeover);
                takeover.onclick = () => {
                    const nextState = !activeHumanTakeover;
                    socket.emit('admin_set_takeover', { userId: id, enabled: nextState });
                };
            }

            function send() {
                const input = document.getElementById('input');
                if(!input.value || !activeUser) return;
                socket.emit('admin_message', { userId: activeUser, text: input.value });
                input.value = '';
            }
            
            function handleKeyPress(e) {
                if (e.key === 'Enter') send();
            }
        </script>
    </body>
    </html>
    `);
});

app.use((error, req, res, next) => {
    console.error('Request Error:', error);
    if (res.headersSent) return next(error);
    const status = Number.isInteger(error.statusCode) && error.statusCode >= 400 && error.statusCode < 500
        ? error.statusCode
        : 500;
    return res.status(status).json({
        error: status === 400 ? 'الطلب غير صالح.' : 'حدث خطأ داخلي. حاول مرة أخرى.'
    });
});

server.listen(PORT, () => console.log(`Server running on port ${PORT}`));